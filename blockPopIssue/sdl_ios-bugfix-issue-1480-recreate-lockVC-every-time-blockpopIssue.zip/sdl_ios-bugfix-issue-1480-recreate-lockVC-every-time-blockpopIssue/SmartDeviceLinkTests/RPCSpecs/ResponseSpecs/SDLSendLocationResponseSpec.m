//
//  SDLSendLocationResponseSpec.m
//  SmartDeviceLink-iOS

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

QuickSpecBegin(SDLSendLocationResponseSpec)



QuickSpecEnd
