//
//  SDLSendHapticDataResponseSpec.m
//  SmartDeviceLink-iOS
//
//  Created by Nicole on 8/4/17.
//  Copyright © 2017 smartdevicelink. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLRPCParameterNames.h"
#import "SDLSendHapticDataResponse.h"

QuickSpecBegin(SDLSendHapticDataResponseSpec)

QuickSpecEnd
