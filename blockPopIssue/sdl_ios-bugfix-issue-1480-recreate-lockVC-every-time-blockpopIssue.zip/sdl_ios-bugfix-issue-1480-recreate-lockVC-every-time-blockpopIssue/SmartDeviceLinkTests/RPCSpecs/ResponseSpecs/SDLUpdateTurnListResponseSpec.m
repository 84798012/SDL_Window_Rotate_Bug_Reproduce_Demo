//
//  SDLUpdateTurnListResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLUpdateTurnListResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLUpdateTurnListResponseSpec)

QuickSpecEnd
