//
//  SDLUnregisterAppInterfaceResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLUnregisterAppInterfaceResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLUnregisterAppInterfaceResponseSpec)

QuickSpecEnd
