//
//  SDLDialNumberResponseSpec.m
//  SmartDeviceLink-iOS

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

QuickSpecBegin(SDLDialNumberResponseSpec)

QuickSpecEnd
