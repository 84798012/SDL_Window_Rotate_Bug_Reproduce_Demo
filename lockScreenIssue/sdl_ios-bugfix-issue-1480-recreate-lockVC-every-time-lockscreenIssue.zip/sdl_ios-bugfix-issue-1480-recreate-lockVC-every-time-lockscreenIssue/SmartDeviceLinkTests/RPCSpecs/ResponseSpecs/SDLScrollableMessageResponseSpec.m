//
//  SDLScrollableMessageResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLScrollableMessageResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLScrollableMessageResponseSpec)

QuickSpecEnd
