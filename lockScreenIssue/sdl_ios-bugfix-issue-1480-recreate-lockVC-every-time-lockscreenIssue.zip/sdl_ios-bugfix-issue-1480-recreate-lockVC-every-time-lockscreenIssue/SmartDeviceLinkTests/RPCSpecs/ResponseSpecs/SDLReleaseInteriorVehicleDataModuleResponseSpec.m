//
//  SDLReleaseInteriorVehicleDataModuleResponseSpec.m
//  SmartDeviceLinkTests
//
//  Created by standa1 on 7/29/19.
//  Copyright © 2019 smartdevicelink. All rights reserved.
//
#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLReleaseInteriorVehicleDataModuleResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLReleaseInteriorVehicleDataModuleResponseSpec)

QuickSpecEnd

