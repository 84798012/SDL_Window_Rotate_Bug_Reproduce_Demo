//
//  SDLSpeakResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLSpeakResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLSpeakResponseSpec)

QuickSpecEnd
