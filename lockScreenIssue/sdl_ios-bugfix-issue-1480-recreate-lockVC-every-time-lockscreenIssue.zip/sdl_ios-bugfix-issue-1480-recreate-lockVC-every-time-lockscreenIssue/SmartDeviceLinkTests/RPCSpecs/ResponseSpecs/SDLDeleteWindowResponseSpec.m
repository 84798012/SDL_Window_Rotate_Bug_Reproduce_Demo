//
//  SDLDeleteWindowResponseSpec.m
//  SmartDeviceLinkTests

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLDeleteWindowResponse.h"

QuickSpecBegin(SDLDeleteWindowResponseSpec)

QuickSpecEnd
