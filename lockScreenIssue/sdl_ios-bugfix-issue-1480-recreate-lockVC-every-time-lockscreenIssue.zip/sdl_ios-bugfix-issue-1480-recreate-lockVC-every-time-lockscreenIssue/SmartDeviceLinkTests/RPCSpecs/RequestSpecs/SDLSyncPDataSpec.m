//
//  SDLSyncPDataSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLSyncPData.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLSyncPDataSpec)

QuickSpecEnd
