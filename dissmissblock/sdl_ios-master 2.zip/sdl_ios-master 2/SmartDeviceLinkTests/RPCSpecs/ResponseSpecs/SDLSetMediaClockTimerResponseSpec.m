//
//  SDLSetMediaClockTimerResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLSetMediaClockTimerResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLSetMediaClockTimerResponseSpec)

QuickSpecEnd
