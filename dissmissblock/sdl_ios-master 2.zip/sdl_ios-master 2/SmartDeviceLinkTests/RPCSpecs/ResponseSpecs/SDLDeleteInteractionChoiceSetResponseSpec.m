//
//  SDLDeleteInteractionChoiceSetResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLDeleteInteractionChoiceSetResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLDeleteInteractionChoiceSetResponseSpec)

QuickSpecEnd
