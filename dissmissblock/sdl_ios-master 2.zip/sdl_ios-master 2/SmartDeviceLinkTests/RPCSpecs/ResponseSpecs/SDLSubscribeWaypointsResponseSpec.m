//  SDLSubscribeWaypointsResponseSpec.m
//

#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLSubscribeWaypointsResponse.h"

QuickSpecBegin(SDLSubscribeWaypointsResponseSpec)

QuickSpecEnd
