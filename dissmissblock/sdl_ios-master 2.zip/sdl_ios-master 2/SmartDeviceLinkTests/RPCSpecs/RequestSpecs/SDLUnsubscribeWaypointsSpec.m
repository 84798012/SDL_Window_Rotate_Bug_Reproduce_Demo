//  SDLUnsubscribeWaypointsSpec.m
//

#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLUnsubscribeWaypoints.h"

QuickSpecBegin(SDLUnsubscribeWaypointsSpec)

QuickSpecEnd
