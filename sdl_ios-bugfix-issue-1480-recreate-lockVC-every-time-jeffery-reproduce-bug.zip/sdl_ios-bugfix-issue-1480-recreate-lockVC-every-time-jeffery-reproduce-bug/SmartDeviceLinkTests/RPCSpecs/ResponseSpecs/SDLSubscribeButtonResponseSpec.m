//
//  SDLSubscribeButtonResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLSubscribeButtonResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLSubscribeButtonResponseSpec)

QuickSpecEnd
