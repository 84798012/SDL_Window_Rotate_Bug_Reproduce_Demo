//
//  SDLCreateWindowResponseSpec.m
//  SmartDeviceLinkTests

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLCreateWindowResponse.h"

QuickSpecBegin(SDLCreateWindowResponseSpec)

QuickSpecEnd
