//
//  SDLCreateInteractionChoiceSetResponseSpec.m
//  SmartDeviceLink


#import <Foundation/Foundation.h>

#import <Quick/Quick.h>
#import <Nimble/Nimble.h>

#import "SDLCreateInteractionChoiceSetResponse.h"
#import "SDLRPCParameterNames.h"

QuickSpecBegin(SDLCreateInteractionChoiceSetResponseSpec)

QuickSpecEnd
